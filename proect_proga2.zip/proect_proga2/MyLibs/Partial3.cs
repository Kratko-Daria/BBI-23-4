using System;
using System.Collections.Generic;


   
     partial class ConcertManager
    {
        
        public void SortByType()
        {
            for (int i = 0; i < concerts.Count; i++)
            {
                for (int j = i + 1; j < concerts.Count; j++)
                {
                    if (String.Compare(concerts[i].GetType().ToString(), concerts[j].GetType().ToString()) == -1)
                    {
                        Concert tmp = concerts[i];
                        concerts[i] = concerts[j];
                        concerts[j] = tmp;
                    }
                }
            }
        }

        public void SortByArtist()
        {
            for (int i = 0; i < concerts.Count; i++)
            {
                for (int j = i + 1; j < concerts.Count; j++)
                {
                    if (String.Compare(concerts[i].Artist, concerts[j].Artist) == -1)
                    {
                        Concert tmp = concerts[i];
                        concerts[i] = concerts[j];
                        concerts[j] = tmp;
                    }
                }
            }
        }

        public void SortByDate()
        {
            for (int i = 0; i < concerts.Count; i++)
            {
                for (int j = i + 1; j < concerts.Count; j++)
                {
                    if (concerts[i].Date > concerts[j].Date)
                    {
                        Concert tmp = concerts[i];
                        concerts[i] = concerts[j];
                        concerts[j] = tmp;
                    }
                }
            }
        }

        public override string ToString()
        {
            string res = "";
            List<Concert> sorted_concerts = new List<Concert>(concerts);
            // Сортировка по типу, потом по дате
            for (int i = 0; i < concerts.Count; i++)
            {
                for (int j = i + 1; j < concerts.Count; j++)
                {
                    int flag_type = String.Compare(sorted_concerts[i].GetType().ToString(), sorted_concerts[j].GetType().ToString());
                    bool flag_date = sorted_concerts[i].Date > sorted_concerts[j].Date;
                    if ((flag_type == 1) || (flag_type == 0) && flag_date)
                    {
                        Concert tmp = concerts[i];
                        concerts[i] = concerts[j];
                        concerts[j] = tmp;
                    }
                }
                res += concerts[i].ToString() + "\n";
            }
            return res;
        }
    }
