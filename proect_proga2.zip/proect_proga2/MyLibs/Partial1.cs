using System;
using System.Collections.Generic;


    partial class ConcertManager : IConcertManager
    {
        public List<Concert> concerts = new List<Concert>();
        public void AddConcert(Concert concert)
        {
            concerts.Add(concert);
        }

        public void RemoveConcert(int index)
        {
            concerts.Remove(concerts[index]);
        }

        public void DisplayConcerts()
        {
            foreach (var concert in concerts)
            {
                Console.WriteLine(concert.ToString());
            }
        }
        
       
    }

 