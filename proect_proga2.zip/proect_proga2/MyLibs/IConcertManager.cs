
interface IConcertManager
    {
        void AddConcert(Concert concert);
        void RemoveConcert(int index);
        void DisplayConcerts();
      
    }

