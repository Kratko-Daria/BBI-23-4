using System;

partial class ConcertManager
    {
        public void Filter(Type type)
        {
            foreach (var concert in concerts)
            {
                if (concert.GetType() == type)
                {
                    Console.WriteLine(concert.ToString());
                }
            }
        }



        public void Filter(string artist)
        {
            foreach (var concert in concerts)
            {
                if (concert.Artist == artist) //|| (concert.GetType().ToString() == artist))
                {
                    Console.WriteLine(concert.ToString());
                }
            }
        }

        public void Filter(DateTime date)
        {
            foreach (var concert in concerts)
            {
                if (concert.Date == date)
                {
                    Console.WriteLine(concert.ToString());
                }
            }
        }
    }
