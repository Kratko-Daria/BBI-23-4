﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    abstract class Concert
    {
        public string Name { get; private set; }
        public string Artist { get; private set; }
        public string Venue { get; private set; }
        public DateTime Date { get; private set; }

        public Concert(string Name, string Artist, string Venue, DateTime Date)
        {
            this.Name = Name;
            this.Artist = Artist;
            this.Venue = Venue;
            this.Date = Date;

        }
        public override string ToString()
        {
            return $"Concert: {Name}, Artist: {Artist}, Venue: {Venue}, Date: {Date}";
        }
    }

    class ClassicConcert : Concert
    {
        public string Composer { get; private set; }

        public ClassicConcert(string Name, string Artist, string Venue, DateTime Date, string Composer) : base(Name, Artist, Venue, Date)
        { this.Composer = Composer; }
        public override string ToString()
        {
            return base.ToString() + $", Composer: {Composer}";
        }
    }

    class RockConcert : Concert
    {
        public string Genre { get; private set; } = "Рок-концерт";

        public RockConcert(string Name, string Artist, string Venue, DateTime Date) : base(Name, Artist, Venue, Date)
        { this.Genre = Genre; }
        public override string ToString()
        {
            return base.ToString() + $", Genre: {Genre}";
        }
    }
    class AcousticRockConcert : RockConcert
    {
        public bool isSymphonic { get; set; }
        public AcousticRockConcert(string name, string artist, string venue, DateTime dateTime,/* string genre,*/ bool isSymphonic) : base(name, artist, venue, dateTime)
        {
            this.isSymphonic = isSymphonic;
        }

        public override string ToString()
        {
            return base.ToString() + $", isSymphonic: {isSymphonic}";
        }
        public void SetSymphotic(bool flag)
        {
            this.isSymphonic = flag;
        }

        public bool GetIsSymphonic() { return this.isSymphonic; }


    }


    class RapConcert : Concert
    {
        public string Rapper { get; private set; } = "Реп-концерт";

        public RapConcert(string Name, string Artist, string Venue, DateTime Date) : base(Name, Artist, Venue, Date)
        { }

        public override string ToString()
        {
            return base.ToString() + $", Rapper: {Rapper}";
        }
    }

