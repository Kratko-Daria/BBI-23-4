using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Xml;

abstract class MySerializer
  {
      public abstract void Read(string filename);
      public abstract void Write(ConcertManager concertManager, string filename);
  }

  class MyJsonSerializer : MySerializer

  {
      public override void Read(string filename)
      {
          try
          {
          using (StreamReader r = new StreamReader(filename))
          {
              string json = r.ReadToEnd();
              string[] jsn = GetJsonsArray(json);
              Console.WriteLine($"\nConcerts read successfully from {filename}:");
              for (int i = 0; i < jsn.Length; i++)
              {                    
                  if (jsn[i].Contains("\"Genre\":"))
                  {
                      RockConcert c = JsonConvert.DeserializeObject<RockConcert>(jsn[i]);
                      Console.WriteLine(c.ToString());
                  }
                  else if (jsn[i].Contains("\"Rapper\":"))
                  {
                      RapConcert c = JsonConvert.DeserializeObject<RapConcert>(jsn[i]);
                      Console.WriteLine(c.ToString());
                  }
                  else if (jsn[i].Contains("\"Composer\":"))
                  {
                      ClassicConcert c = JsonConvert.DeserializeObject<ClassicConcert>(jsn[i]);
                      Console.WriteLine(c.ToString());
                  }
              }

              //List<Concert> concerts = JsonConvert.DeserializeObject<List<Concert>>(jsonn;
              //Console.WriteLine($"Concerts read successfully from {filename}:");
              /*   foreach (var concert in concerts)
                 {
                     Console.WriteLine(concert.ToString());
                 }*/
          }
          }
         catch (Exception ex)
          {
              Console.WriteLine($"Error reading JSON file: {ex.Message}");
          }
      }
      private  static string[] GetJsonsArray(string json)
      {     
            json=json.Replace("\r\n", "");
            string[] temp = json.Split('[');
            json = temp[1];
            Array.Resize(ref temp, 0);
            temp = json.Split(']');
            json = temp[0]; 
            Array.Resize(ref temp, 0);
            temp = json.Split('}');
            Array.Resize(ref temp, temp.Length-1);
            for (int i = 1;i<temp.Length;i++)
            {
                temp[i] = temp[i].Substring(1, temp[i].Length-1);
                temp[i] = temp[i] + "}";
            }
            temp[0] = temp[0] + "}";
            return temp;

      }
      public override void Write(ConcertManager concertManager, string filename)
      {
          try
          {
              string json = JsonConvert.SerializeObject(concertManager, Newtonsoft.Json.Formatting.Indented);
              File.WriteAllText(filename, json);
              Console.WriteLine($"Concerts written to JSON file {filename} successfully.");
          }
          catch (Exception ex)
          {
              Console.WriteLine($"Error writing JSON file: {ex.Message}");
          }
      }
  }
  class MyXMLSerializer : MySerializer
  {
      public override void Read(string filename)
      {
          string res;
          Console.WriteLine($"\nЧтение XML из {filename}");
      using (FileStream fstream = new FileStream(filename, FileMode.Open))
          {
           byte[] buffer = new byte[fstream.Length];
              fstream.Read(buffer, 0, buffer.Length);
          res = System.Text.Encoding.Default.GetString(buffer);// Encoding.UTF8.GetString(buffer);
          }

          XmlDocument doc = new XmlDocument();
          doc.LoadXml(res.Replace("&", ""));

          var manager = doc.DocumentElement.ChildNodes;
          foreach (XmlNode node in manager)
          {
              string name = node.ChildNodes.Item(1).InnerText;
              string artist = node.ChildNodes.Item(2).InnerText;
              string venue = node.ChildNodes.Item(3).InnerText;
              string datetime_str = node.ChildNodes.Item(4).InnerText;
              DateTime myDate = DateTime.ParseExact(datetime_str, "dd.MM.yyyy HH:mm:ss",
                                         System.Globalization.CultureInfo.InvariantCulture);

              string type_str = node.ChildNodes.Item(0).InnerText;
              if (type_str == "ClassicConcert")
              {
                  var extra = node.ChildNodes.Item(5).InnerText;
                  ClassicConcert c = new ClassicConcert(name, artist, venue, myDate, extra);
                  Console.WriteLine(c);
              }
              if (type_str == "RockConcert")
              {
                  var extra = node.ChildNodes.Item(5).ChildNodes.Item(0).InnerText;
                  RockConcert c = new RockConcert(name, artist, venue, myDate);
                  Console.WriteLine(c);
              }
              if (type_str == "AcousticRockConcert")
              {
                  string extraS = node.ChildNodes.Item(5).ChildNodes.Item(0).InnerText;// node.ChildNodes.Item(5).ChildNodes.Item(1).InnerText;
              extraS =extraS.ToUpper();
                  bool extra= false; 
                  if (extraS=="TRUE") extra=true; 
                  AcousticRockConcert c = new AcousticRockConcert(name, artist, venue, myDate,extra);
                  Console.WriteLine(c);
              }
              if (type_str == "RapConcert")
              {
                  var extra = node.ChildNodes.Item(5).InnerText;
                  RapConcert c = new RapConcert(name, artist, venue, myDate);
                  Console.WriteLine(c);
              }
          }
      }

      public override void Write(ConcertManager concertManager, string filename)
      {
          string res = "<concertManger>\n";
          for (int i = 0; i < concertManager.concerts.Count; i++)
          {
              res += GetXMLConcert(concertManager.concerts[i]);
          }
          res += "</concertManger>\n";
          using (FileStream fstream = new FileStream(filename, FileMode.Create))
          {
              byte[] buffer = Encoding.Default.GetBytes(res);
              fstream.Write(buffer, 0, buffer.Length);
          }
          Console.WriteLine($"XML записан в {filename}!");
      }

      private string GetXMLConcert(Concert c)
      {
          string res = "<concert>\n";
          Type type = c.GetType();

          res += $"<type>{type.ToString()}</type>\n";
          res += $"<Name>{c.Name}</Name>\n";
          res += $"<Artist>{c.Artist}</Artist>\n";
          res += $"<Venue>{c.Venue}</Venue>\n";
          res += $"<Date>{c.Date}</Date>\n";

          res += "<extra>\n";
          if (typeof(ClassicConcert) == type)
          {
              res += $"<Composer>{((ClassicConcert)c).Composer}</Composer>\n";
          }
          if (typeof(RockConcert) == type)
          {
              res += $"<Genre>{((RockConcert)c).Genre}</Genre>\n";
          }
          if (typeof(AcousticRockConcert) == type)
          {
              res += $"<isSymphonic>{((AcousticRockConcert)c).GetIsSymphonic()}</isSymphonic>\n";
          }
          if (typeof(RapConcert) == type)
          {
              res += $"<Rapper>{((RapConcert)c).Rapper}</Rapper>\n";
          }
          res += "</extra>\n";

          res += "</concert>\n";
          return res;
      }
  }
