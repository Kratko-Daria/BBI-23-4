﻿using System;
using System.IO;


internal class Program
    {
        static void Main(string[] args)

        {
            string MyPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            MyPath += @"\ConcertData\";
            if (!Directory.Exists(MyPath))
            {
                Directory.CreateDirectory(MyPath);
            }


            RockConcert[] rock = new RockConcert[15] {
                new RockConcert("Rock Revolution" ,"Louna","Клуб \"Театръ\"", new DateTime(2024,06, 01, 19, 30,0)),
                new RockConcert("Битва гитаристов" ,"Tracktor Bowling","Клуб \"ГлавClub Green Concert\"", new DateTime(2024,06, 15, 19, 30,0)),
                new RockConcert("Рок Фестиваль" ,"Animal ДжаZ","Открытая площадка \"Лужники\"",new DateTime(2024, 08, 17, 19, 30, 0)),
                new RockConcert("Rock Live","Пилот", "Клуб \"16 тонн\"",new DateTime(2024, 08, 17, 19, 30, 0)),
                new RockConcert("Underground Rock","Slot","Клуб \"Agava Club\"",new DateTime(2024, 09, 07, 19, 30, 0)) ,
                new RockConcert("Рок Вечеринка","Noize", "Клуб \"Agava Club\"",new DateTime(2024, 09, 14, 19, 30, 0)),
                new RockConcert("Рок Фестиваль","Animal ДжаZ","Открытая площадка \"Лужники\"",new DateTime(2024, 09, 14, 19, 30, 0)),
                new RockConcert("Рок-Авангард","АукцЫон", "Клуб \"Red\"",new DateTime(2024, 10, 05, 19, 30, 0)),
                new RockConcert("Хард-Рок Стэндап","КняZz", "Клуб \"Rock House\"",new DateTime(2024, 10, 19, 19, 30, 0)),
                new RockConcert("Рок-Эксплозия","The Hatters", "Открытая площадка \"Лужники\"",new DateTime(2024, 11, 02, 19, 30, 0)),
                new RockConcert("Rock Battle","Пурген", "Клуб \"16 тонн\"",new DateTime(2024, 11, 16, 19, 30, 0)),
                new RockConcert("Rock Live","Пилот", "Клуб \"Glastonberry Pub\"",new DateTime(2024, 12, 14, 19, 30, 0)),
                new RockConcert("Underground Rock","Slot", "Клуб \"Agava Club\"",new DateTime(2024, 12, 14, 19, 30, 0)),
                new RockConcert("Рок Вечеринка","Noize", "Клуб \"MOD Club\"",new DateTime(2024, 12, 28, 19, 30, 0)),
                new RockConcert("Rock Battle", "Пурген", "Клуб \"Москва Hall\"", new DateTime(2024, 12, 30, 19, 30, 0))};

            AcousticRockConcert[] rockA = new AcousticRockConcert[10] {
                new AcousticRockConcert("Группа Крови","Кино","Открытая площадка \"Лужники\"", new DateTime(2024,06, 01, 19, 30,0),false),
                new AcousticRockConcert("Концерт" ,"Шнипельсон и Потамушт","Арт-кафе Пушкарев", new DateTime(2024,06, 15, 19, 30,0),false),
                new AcousticRockConcert("Концерт" ,"Константин Никольский","Академ Джаз Клуб",new DateTime(2024, 08, 17, 19, 30, 0),false),
                new AcousticRockConcert("Концерт" ,"Константин Никольский", "Союз Композиторов",new DateTime(2024, 08, 17, 19, 30, 0),false),
                new AcousticRockConcert("Концерт" ,"Константин Никольский","Академ Джаз Клуб",new DateTime(2024, 09, 07, 19, 30, 0),false) ,
                new AcousticRockConcert("Концерт","Андрей ГрейЧайник", "Клуб \"GlastonBerry\"",new DateTime(2024, 09, 14, 19, 30, 0),false),
                new AcousticRockConcert("Группа Крови","Кино","Открытая площадка \"Лужники\"",new DateTime(2024, 09, 14, 19, 30, 0),false),
                new AcousticRockConcert("Концерт","Конъюнктура", "Бар Нуар",new DateTime(2024, 10, 05, 19, 30, 0),false),
                new AcousticRockConcert("Концерт" ,"Шнипельсон и Потамушт", "Клуб \"GlastonBerry\"",new DateTime(2024, 10, 19, 19, 30, 0),false),
                new AcousticRockConcert("Группа Крови","Кино","Открытая площадка \"Лужники\"",new DateTime(2024, 11, 02, 19, 30, 0),false),
              };

            RapConcert[] rap = new RapConcert[15] {
                new RapConcert( "Rap Live" ,"Скриптонит","Adrenaline Stadium", new DateTime(2024,06, 01, 19, 30,0)),
                new RapConcert("Город рэпа","Скриптонит","Stadium Live", new DateTime(2024,06, 15, 19, 30,0)),
                new RapConcert( "Хип-хоп Подземка" ,"Oxxxymiron","Клуб RED",new DateTime(2024, 08, 17, 19, 30, 0)),
                new RapConcert("Битвы на Рэп-Арене" , "Гнойный", "Клуб Lookin Rooms",new DateTime(2024, 08, 17, 19, 30, 0)),
                new RapConcert("РЭПерский квартал","ATL" , "Space Moscow",new DateTime(2024, 09, 07, 19, 30, 0)) ,
                new RapConcert( "Боксерская аллея","Хаски","Adrenaline Stadium",new DateTime(2024, 09, 14, 19, 30, 0)),
                new RapConcert( "Рэп-Марафон","Мияги & Эндшпиль","Stadium Live",new DateTime(2024, 09, 14, 19, 30, 0)),
                new RapConcert( "Улицы Москвы","Каста", "Клуб \"Red\"",new DateTime(2024, 10, 05, 19, 30, 0)),
                new RapConcert("Подпольный стиль","Скриптонит","Клуб Lookin Rooms",new DateTime(2024, 10, 19, 19, 30, 0)),
                new RapConcert("Рэперский фестиваль","Тимати",  "Space Moscow",new DateTime(2024, 11, 02, 19, 30, 0)),
                new RapConcert( "Улицы Москвы","Каста","Adrenaline Stadium",new DateTime(2024, 11, 16, 19, 30, 0)),
                new RapConcert( "Рэп-Марафон","Мияги & Эндшпиль","Stadium Live",new DateTime(2024, 12, 14, 19, 30, 0)),
                new RapConcert( "Город рэпа","Скриптонит", "Space Moscow",new DateTime(2024, 12, 14, 19, 30, 0)),
                new RapConcert("Подпольный стиль","Скриптонит","Клуб Lookin Rooms",new DateTime(2024, 12, 28, 19, 30, 0)),
                new RapConcert( "Боксерская аллея","Хаски", "Клуб RED", new DateTime(2024, 12, 30, 19, 30, 0))};

            ClassicConcert[] cls = new ClassicConcert[15] {
                new ClassicConcert( "Ля минор" ,"Московский симфонический оркестр" ,"Большой зал Консерватории имени П.И. Чайковского", new DateTime(2024,06, 01, 19, 30,0),"П.И.Чайковский"),
                new ClassicConcert("Классический" ,"Русский национальный оркестр","Большой зал Большого театра", new DateTime(2024,06, 15, 19, 30,0),"С.С.Прокофьев"),
                new ClassicConcert( "Ля мажор" , "Санкт-Петербургский филармонический оркестр","Государственный Кремлевский дворец",new DateTime(2024, 08, 17, 19, 30, 0),"Ф.Мендельсон"),
                new ClassicConcert("Ми мажор","Большой театральный оркестр","Музыкальная академия имени Гнесиных",new DateTime(2024, 08, 17, 19, 30, 0),"Н.Мясковский"),
                new ClassicConcert("Греческий","Русский камерный оркестр","Театр оперы и балета имени Е.Светланова",new DateTime(2024, 09, 07, 19, 30, 0),"С.Рахманинов") ,
                new ClassicConcert( "Ре минор","Симфонический оркестр Российского государственного академического Большого театра","Большой зал Консерватории имени П.И. Чайковского", new DateTime(2024, 09, 14, 19, 30, 0),"Ш.Сен-Санс"),
                new ClassicConcert( "Серенада","Оркестр романса","Большой зал Большого театра",new DateTime(2024, 09, 14, 19, 30, 0),"Н.Беляев"),
                new ClassicConcert("Два часа дождя","Русский коллектив народного фольклора","Государственный Кремлевский дворец",new DateTime(2024, 10, 05, 19, 30, 0),"Д.Пёрселл"),
                new ClassicConcert("Тишина","Камерный оркестр Краснодарского края","Музыкальная академия имени Гнесиных",new DateTime(2024, 10, 19, 19, 30, 0),"Г.Урбански"),
                new ClassicConcert("Сковородка","Оркестр классической академии","Театр оперы и балета имени Е.Светланова",new DateTime(2024, 11, 02, 19, 30, 0),"С.Таниев"),
                new ClassicConcert("Ля минор" ,"Московский симфонический оркестр","Большой зал Консерватории имени П.И. Чайковского", new DateTime(2024, 11, 16, 19, 30, 0),"П.И.Чайковский"),
                new ClassicConcert("Классический" ,"Русский национальный оркестр","Большой зал Большого театра",new DateTime(2024, 12, 14, 19, 30, 0),"С.С.Прокофьев"),
                new ClassicConcert("Ля мажор" , "Санкт-Петербургский филармонический оркестр","Государственный Кремлевский дворец",new DateTime(2024, 12, 14, 19, 30, 0),"Ф.Мендельсон"),
                new ClassicConcert( "Ми мажор","Большой театральный оркестр","Музыкальная академия имени Гнесиных",new DateTime(2024, 12, 28, 19, 30, 0),"Н.Мясковский"),
                new ClassicConcert("Греческий","Русский камерный оркестр","Театр оперы и балета имени Е.Светланова", new DateTime(2024, 12, 30, 19, 30, 0),"С.Рахманинов")};

        string[] sfile = new string[] {
            MyPath + "raw_data.json",
            MyPath + "data.json",
            MyPath + "raw_data.xml",
            MyPath + "data.xml",
            MyPath + "new_data.xml",
        };

         ConcertManager concertManager = new ConcertManager();
            for (int i = 0; i < 10; i++)
                concertManager.AddConcert(rock[i]);
            for (int i = 0; i < 10; i++)
                concertManager.AddConcert(rap[i]);
            for (int i = 0; i < 10; i++)
                concertManager.AddConcert(cls[i]);

            MyJsonSerializer jsoner = new MyJsonSerializer();
         jsoner.Write(concertManager, sfile[0]);
            //concertManager.DisplayConcerts();
           

            Concert[] concertsBuf = new Concert[15];

            for (int i = 0; i < 15; i++)
            {
                if (i < 5)
                    concertsBuf[i] = rap[i + 10];
                else if (i < 10)
                    concertsBuf[i] = rock[i + 5];
                else concertsBuf[i] = cls[i];
            }
            Random rand = new Random();
            bool[] isSel = new bool[15];
            for (int i = 0; i < isSel.Length; i++) isSel[i] = false;
            for (int i = 0;i<5; i++)
        {
            int rnd = GetRnd(isSel);
            concertManager.AddConcert(concertsBuf[rnd]);
        }
            jsoner.Write(concertManager, sfile[1]);
           
        
        jsoner.Read(sfile[0]); 
        jsoner.Read(sfile[1]); 

        concertManager.DisplayConcerts();
           Console.WriteLine("\nВсе рок-концерты из Менеджера");
        //  concertManager.Filter("RockConcert");
        concertManager.Filter(rock[0].GetType());

            string FindArtist = "Animal ДжаZ";
            Console.WriteLine($"\nВсе концерты из Менеджера {FindArtist}");
            concertManager.Filter(FindArtist);

            DateTime FindDate = new DateTime(2024, 06, 01, 19, 30, 0);
            Console.WriteLine($"\nВсе концерты из Менеджера в {FindDate}");
            concertManager.Filter(FindDate);

        Console.WriteLine("\nСортировка по дате"); concertManager.SortByDate();
            concertManager.DisplayConcerts();
            MyXMLSerializer xmler = new MyXMLSerializer();
            xmler.Write(concertManager, sfile[2]);

            for (int i = 0; i < 5; i++)
                concertManager.RemoveConcert(0);
         
            Console.WriteLine("\nПосле удаления 5 ближайших");
            concertManager.DisplayConcerts();

            for (int i = 0; i < 10; i++)
                concertManager.AddConcert(rockA[i]);
            xmler.Write(concertManager, sfile[3]);
           
            Console.WriteLine("\nПосле добавления Акустик рока");
            concertManager.DisplayConcerts();

            Console.WriteLine("\nСортировка по типу и дате");
            Console.WriteLine(concertManager);

            Console.WriteLine("\nИзменение типа Акустического рок-концерта");
            int[] temp = new int[concertManager.concerts.Count];
            int nrockA = 0; 
            for (int i = 0; i < concertManager.concerts.Count; i++)
            {
            if (concertManager.concerts[i].GetType() == rockA[0].GetType())
            {
                
                temp[nrockA] = i;
                nrockA++;
            };
             }
           
            Array.Resize(ref temp, nrockA);
            Array.Resize(ref isSel, nrockA);
            for (int i = 0; i < isSel.Length; i++) isSel[i] = false;
            for (int i=0; i < 3;i++)
        {
            int rnd = GetRnd(isSel);
            AcousticRockConcert arc = (AcousticRockConcert)concertManager.concerts[temp[rnd]];
            arc.SetSymphotic(true);
            concertManager.concerts[temp[rnd]] = arc;
        }
            
            xmler.Write(concertManager, sfile[4]);

        for (int i = 2; i < 5; i++) xmler.Read(sfile[i]); 
       
        }
    private static int GetRnd(bool[] mas)
    {
        Random rand = new Random();
        int rnd;
        do
        {
            rnd = rand.Next(mas.Length);
  
        }
        while (mas[rnd]);
        mas[rnd] = true;

        return rnd;
    }
}


//}
